---
name: agent-army-design
description: Design, document, and bootstrap a multi-agent system (agent army) — Commander + Specialist topology, Cloud Brain/Local Spine strategy, per-agent doc set, registry.
version: 1.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [multi-agent, agent-army, solocorp, architecture, documentation]
    related_skills: [kanban-orchestrator, subagent-driven-development, writing-plans]
---

# Agent Army Design — Commander + Specialist Topology

Use this skill when the user wants to design, plan, or bootstrap a fleet of Hermes agents working as a team — whether called "agent army", "SoloCorp OS", "agent fleet", or any equivalent framing.

## Core Strategy: Cloud Brain, Local Spine

**Cloud Brain:** All LLM inference runs on cloud APIs (Claude, Gemini, Kimi, etc.) — no local model hosting required.

**Local Spine:** Orchestration, file I/O, cron scheduling, state storage, and routing run on the user's local machine.

**Why:** Even a modest machine (e.g. 4-core i5, 8 GB RAM) can run 3–5 agents simultaneously at ~200–400 MB RAM each, as long as inference is offloaded to the cloud.

**When to add local LLM:** Only when RAM ≥ 16 GB (for a 7B model). Don't design for this on constrained hardware.

## Topology: Commander + Specialists

```
User (Telegram / CLI)
        │
   hermes-life  ← Commander: receives all user input, routes to specialists
        │
   ┌────┼────┐
hermes-dev  hermes-ops  hermes-X ...
(coding)  (deploy/git)  (specialist)
```

**Commander role (`hermes-life`):**
- Single point of contact for the user
- Interprets intent, decomposes tasks, routes to specialist agents
- Does NOT do the work itself — delegates everything specialist-worthy
- Model: Sonnet (conversational + routing)

**Specialist roles:**
- Each has a narrow, well-defined domain
- Receives structured task descriptions from Commander
- Reports back to Commander (or directly to user if simpler)
- Model matched to task: Sonnet for code, Haiku for simple ops, Opus for architecture

## Phase Progression

### Phase 1 — Level 1: Control Room + One Agent
- Set up `hermes-agent-control-room` repo (see references/)
- Create Commander docs (`agents/hermes-life/`)
- Create first Specialist docs (`agents/hermes-dev/`)
- Build `registry/agents.md`
- No orchestrator, no task bus — manual routing

### Phase 2 — Level 2: Add Specialists + Routing Logic
- Add specialists one at a time — fill doc set per agent (5-file infra set or 4-file SOUL set depending on agent type)
- Update `registry/agents.md` for each new agent — include path, ports, model, status
- Create `docs/task-types.md` — routing guide: per-agent task type table (Task Type / Example / Keywords columns)
- Create `docs/routing.md` — full Telegram → hermes-life → agents flow with decision tree and keyword routing table
- Introduce structured task message format
- When adding a specialist, also add its keyword group rows to `docs/routing.md` and task types to `docs/task-types.md`

**Phase 2 keyword domains (extend per specialist):**
- `hermes-dev`: code, debug, test, build, review
- `hermes-ops`: deploy, release, server, cron, git, backup, monitor, restart, logs
- `hermes-cfo`: เงิน, รายรับ, รายจ่าย, งบ, budget, cashflow, tax, invoice, forecast, investment

### Phase 3 — Level 3+: Scale (new hardware / VPS)
- Move Spine to VPS for always-on reliability
- Add local LLM fallback when RAM allows (≥ 16 GB)
- Full orchestrator + task bus

## Per-Agent Documentation Set (5 files)

Each agent lives at `agents/<slug>/` with these files:

| File | Purpose |
|------|---------|
| `inventory.md` | Role, ports, messaging, credentials, skills |
| `docker.md` | Layout, compose config, common ops |
| `env-map.md` | API keys table: Key/Purpose/Provider/Scope/Stored where/Last rotated |
| `runbook.md` | Talk/Check/Restart/Upgrade/Rotate/Restore procedures |
| `backup.md` | Include/Exclude lists, repo config, restore steps |

**Backup rule:** Always include `SOUL.md`, config, memories, skills, cron. Always exclude `.env`, auth tokens, sessions, logs (security + size).

See `references/agent-doc-templates.md` for fill-in-the-blanks templates for each file.

## Alternate Doc Set: Persona-Heavy Specialists (SOUL pattern)

Operational specialists (dev/ops) use the 5-file infra-oriented set above. **Persona-heavy specialists** — agents whose value is judgment, voice, and decision framework rather than infra (e.g. CFO, Legal, Strategist) — use a different 4-file set focused on character + behaviour:

| File | Purpose |
|------|---------|
| `SOUL.md` | Identity, personality, principles, decision framework, red lines, output format |
| `runbook.md` | Procedures: how the agent runs check-ins, audits, periodic tasks |
| `capabilities.md` | What it can/can't do, scope boundaries, hand-off rules to other agents |
| `examples.md` | 3–5 worked examples with real numbers (input → reasoning → output) |

**When to use which shape:**
- Need infra ops (docker, env keys, backup)? → 5-file infra set
- Need strong persona + decision rules + worked examples? → 4-file SOUL set
- Some agents may eventually want both — start with the one that matches the primary value, add the other later.

**Location convention:**
- Repo-tracked agents (infra-heavy, shared, version-controlled): `~/agent-control-room/agents/<slug>/`
- Personal/persona agents (user-specific voice, may contain private financial/personal context): `~/.hermes/agents/<slug>/`

The registry must still link to both — list the path explicitly in `registry/agents.md` for each agent.

See `references/persona-specialist-template.md` for the SOUL pattern template, with hermes-cfo as a worked example (Cash-is-King CFO with veto power, Best/Base/Worst case output, Thai tax rules).

## Registry

`registry/agents.md` — single source of truth listing all agents:
- Slug, role type (Commander/Specialist), status (active/planned)
- Ports assigned, model used, brief description
- Cross-links to each agent's `inventory.md`

Update registry every time an agent is added or decommissioned.

## Naming Convention

Agent slugs follow `hermes-<domain>` pattern:
- `hermes-life` — Commander / personal assistant
- `hermes-dev` — coding, debugging, code review
- `hermes-ops` — deploy, git, cron, infra
- `hermes-cfo` — finance, budget, tax, cash flow, investment decisions
- `hermes-data` — data pipelines, analysis
- `hermes-research` — web research, summarization

## Port Allocation Table

| Agent | API Port | Dashboard Port |
|-------|----------|----------------|
| hermes-life | 8642 | 9119 |
| hermes-dev  | 8643 | 9120 |
| hermes-ops  | 8644 | 9121 |
| hermes-cfo  | 8645 | 9122 |
| hermes-X (next) | 8646 | 9123 |

Pattern: API = 8642 + index, Dashboard = 9119 + index (0-indexed from hermes-life).

## Resource Planning (per agent)

- **RAM footprint:** ~200–400 MB per running agent
- **Safe concurrency:** (available_RAM − 1 GB headroom) / 350 MB
  - Example: 4 GB available → ~8 agents theoretically, 3–4 safely
- **MySQL:** reuse existing instance as state/job store — no new DB needed
- **Default ports:** 8642 (gateway/API), 9119 (dashboard) per agent (offset by agent index to avoid collision)

## Scaffold Repo

`https://github.com/shannhk/hermes-agent-control-room` — contains:
- `docs/` — architecture, levels, naming, orchestrator pattern, starter guide
- `templates/agent/` — the 5-file templates (inventory, docker, env-map, runbook, backup)
- `skills/` — setup-control-room and agent-control-room SKILL.md files

Clone to `~/agent-control-room/` and fill templates per agent.

## Step-by-Step Bootstrap

### Phase 1
1. `git clone https://github.com/shannhk/hermes-agent-control-room ~/agent-control-room`
2. Read `docs/starter-guide.md` and `docs/levels.md` to confirm target level
3. Run system resource check: RAM, CPU, disk, running services
4. Decide Cloud Brain vs Local Spine split based on available RAM
5. Create `agents/hermes-life/` — fill all 5 files from templates
6. Create `agents/hermes-dev/` — fill all 5 files
7. Create `registry/agents.md` — list both agents (hermes-life as Commander, hermes-dev as Specialist)
8. Commit and push
9. Verify: `ls agents/*/` shows all 5 files per agent

### Phase 2
10. Create `agents/hermes-ops/` — fill all 5 files (keywords: deploy, release, server, cron, git, backup, monitor, restart, logs)
11. Patch `registry/agents.md` — add hermes-ops to Active Agents section (not Planned)
12. Create `docs/task-types.md` — table per agent: Task Type / Example / Keywords
13. Create `docs/routing.md` — decision tree: Telegram → hermes-life → specialist, with keyword routing table
14. After any multi-patch to registry, verify footer has no duplicate `Last updated:` line
15. Commit and push

## Pitfalls

**Don't design Local LLM into Phase 1 on constrained hardware.** RAM < 16 GB means cloud-only. Plan for local LLM as a future upgrade gate, not a current dependency.

**Don't conflate Commander with Kanban Orchestrator.** Commander (hermes-life) is a Hermes profile that routes via conversation and cron. Kanban Orchestrator is a different pattern using the Kanban board tool. They can coexist but serve different granularities.

**Registry drift.** If you add an agent but forget to update `registry/agents.md`, the registry becomes stale. Always update registry as the last step when adding any agent. When an agent lives outside the repo (e.g. `~/.hermes/agents/<slug>/`), record its full path explicitly in the registry.

**Port collisions.** If running multiple agents on the same machine, offset ports by agent index. Don't hardcode 8642/9119 for every agent.

**env-map ≠ .env file.** `env-map.md` is documentation of what keys exist and where they're stored — it does NOT contain actual key values. Actual values live in `.env` (gitignored).

**Registry patch duplicate date.** When patching `registry/agents.md` in multiple rounds (e.g. move agent + add fields as separate patches), the `> Last updated:` footer line can end up duplicated as `> Last updated: DATE | DATE`. Always check the footer after multi-round patches and clean it up.

**Routing docs must grow with each specialist.** When adding a specialist, patch BOTH `docs/routing.md` (keyword groups + decision tree branch) and `docs/task-types.md` (task type rows + multi-agent flow entries). These are not one-time writes — they are living docs that expand per agent.

**SOUL-pattern agents may contain private data.** When `examples.md` includes real financial figures, personal health data, or legal details, the agent should live at `~/.hermes/agents/` (gitignored), NOT in the shared repo. The registry links to it but doesn't expose content.

**Phase 2 docs are deliverables, not optional.** `docs/task-types.md` and `docs/routing.md` are required Phase 2 outputs — they encode how hermes-life decides where to route. Without them the Commander has no routing logic to reference.