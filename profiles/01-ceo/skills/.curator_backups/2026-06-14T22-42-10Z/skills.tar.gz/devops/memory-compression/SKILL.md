---
name: memory-compression
description: Compress Hermes persistent memory when near capacity — deduplicate, merge, and reclaim space without data loss
triggers:
  - Memory usage above 85%
  - memory tool returns "would put memory at X/2200 chars" error
  - User asks to clean up / compress / reorganize memory
---

# Memory Compression

## When to Use
- Memory at 85%+ capacity (2,200 char limit)
- Cannot add new entries due to space
- Entries have accumulated duplicates or overlap with User Profile

## Procedure

### Phase 1: Remove Before Adding
**Critical pitfall:** You CANNOT replace an entry with a longer merged version if memory is near-full. The replacement is checked against capacity BEFORE the old entry is freed. Always DELETE entries first to create headroom, THEN replace/add merged versions.

### Phase 2: Identify Redundancy (3 sources)
1. **Duplicates with User Profile** — Memory entries that repeat what's already in USER.md (timezone, language, job title, tech stack, location). Safe to delete outright.
2. **Splinter entries** — Multiple entries in the same category that could be one sentence with `|` separators (e.g., 3 "Who I Am" entries → 1).
3. **Verbose entries** — Entries with unnecessary explanation that can be tightened.

### Phase 3: Execution Order
1. Remove duplicates with User Profile first (biggest space gain, zero info loss)
2. Remove splinter entries that will be merged
3. Replace/add merged versions using `|` as inline separator
4. Verify final usage % and entry count

### Phase 4: Verify
- Confirm password hints / sensitive data retained if user requested
- Confirm no semantic information was lost (just presentation compressed)
- Report before/after: entry count, char usage, % freed

## Compression Patterns
- `entry1 + entry2 + entry3` → single entry with `|` separators
- Remove category prefixes where they duplicate the section header visible in memory display
- Shorten `**bold key:** long explanation` → `**bold key:** terse value`

## Pitfalls
- **Replace-before-delete fails:** Memory tool checks new size against current capacity. Always free space first.
- **User Profile overlap:** Entries about location, language, job role, tech stack are already in USER.md — memory entries for these are pure waste.
- **Don't lose sentiment:** Entries carrying emotional weight (e.g. "ครอบครัวปกป้องกัน") — compress but don't flatten meaning.
- **Password hints / credentials:** User may want these kept despite security concerns. Always ask, never unilaterally delete credentials.
- **Char counting:** The 2,200 limit includes all formatting (bold markers, separators, etc). Account for `|` and spaces when estimating merged entry size.

## Typical Results
- 99% → 73% (from 24 → 15 entries) in one pass
- Frees ~500-600 chars for new entries
